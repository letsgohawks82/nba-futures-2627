# 3-2-1 lottery: sources consulted 2026-10-15 (WebFetch summaries; official release is source 1)
1. https://www.nba.com/news/nba-board-governors-approve-new-draft-lottery-system (May 28 2026)
2. https://www.espn.com/nba/story/_/id/48903380/sources-nba-bog-votes-expand-lottery-disincentivizes-tanking
3. https://www.hoopsrumors.com/2026/05/nbas-board-of-governors-approves-3-2-1-lottery-reform-plan.html
4. https://www.cbssports.com/nba/news/nba-new-draft-lottery-system-tanking/ (silent on mechanics)
5. https://www.nba.com/news/key-dates ; https://www.yardbarker.com/nba/articles/2027_nba_trade_deadline_set_for_february_11/s1_14822_44140863
Allocation (agreed by 1,2,3): 16 teams, 37 balls = 3 worst x2 (6) + 4th-10th worst x3 (21) + #9/#10 seeds x4 teams x2 (8) + 7v8 play-in losers x2 teams x1 (2).
Floor: 3 worst can fall to 12th; all others to 16th. All 16 first-round picks drawn.
Restrictions: own pick no #1 in consecutive drafts; no top-5 in 3 consecutive drafts; apply retroactively (2025, 2026) and regardless of trade (1,3). ESPN: Utah 2027 pick (owned by MEM) no higher than 6th; Washington (won 2026 #1) cannot get #1.
No top-12..15 protections on newly traded picks; existing protections stand. League may cut odds/modify position/fine for tanking. Applies 2027-2029 drafts.
Key dates: reg season Oct 20 2026; Cup groups Oct 30-Nov 27, QF Dec 4-5, SF Dec 8/9, final Dec 11; trade deadline Feb 11 2027 3pm ET; All-Star Feb 19-21; RS ends Apr 11; play-in Apr 13-16.
NOT specified in any source: number/sequence of draws, handling of a restricted team's ball drawn at a blocked slot, whether 7v8 loser who wins the 2nd play-in game keeps its ball (balls attach to 7v8 losers per release), draw order.
